Hatena.Star.SiteConfig = {
  entryNodes: {
    'div.section': {
      uri: 'h2 a',
      title: 'h2',
      container: 'h2'
    }
  }
};
