$(document).ready(function(){					 

	$("body").append("<div class=\"debug-tool\"></div>");
	$("div.debug-tool").load("./debug/debug.html");
	
});